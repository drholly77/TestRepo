import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MapAnd2DArrayProblems {
	
	/**
	 * In this problem, you are given a 2D array of int  
	 * You are to compute and return the sum of all the odd integers
	 * found in the 2D array.
	 * 
	 * Operation: sumOfAllOddNumbers
	 * 
	 * Incoming values:
	 * @param a1: int[][]
	 * @return int - a sum of all the numbers in a1 which are odd
	 * 
	 * Hint: The modulus operator may be helpful: 
	 *       (x % y)  gives the remainder of x divided by y.
	 * 
	 * Example 1
	 * Incoming value:
	 *    a1 = {{47, 55}, {23, 7}}
	 *    
	 * Outgoing value:
	 *    132
	 *    
	 *    
	 * Example 2
	 * Incoming value:
	 *    a1 = {{46, 22}, {0, 100}}
	 *    
	 * Outgoing value:
	 *    0
	 *    
	 */
	public static int sumOfAllOddNumbers(int[][] a1) {
		return -1;
	} // sumOfAllOddNumbers


	/**
	 * In this problem, you are given a 2D array of int
	 * You are find the smallest number in each column of the 2D array
	 * and return these numbers in an ArrayList where location zero of the
	 * ArrayList contains the smallest number from column zero, location one
	 * of the ArrayList contains the smallest number from column one, and so on.
	 * 
	 * Operation: getColumnMinimums
	 * 
	 * Incoming values:
	 * @param a1: int[][]
	 * 
	 * Outgoing value:
	 * @return: ArrayList<Integer> - where ...
	 *          location zero of ArrayList contains the smallest value found in column zero of a1
	 *          location one of ArrayList contains the smallest value found in column one of a1
	 *          location two of ArrayList contains the smallest value found in column two of a1
	 *          etc.
	 *          
	 * Example 1
	 * Incoming value:
	 *    a1 = {{47, -55}, {23, 7}}
	 *    
	 * Outgoing value:
	 *    [23, -55]
	 *    
	 *    
	 * Example 2
	 * Incoming value:
	 *    a1 = {{10, 17, -5}, {32, 5, 7}, {3, 7, 1}}
	 *    
	 * Outgoing value:
	 *    [3, 5, -5]
	 *    
	 */
	public static ArrayList<Integer> getColumnMinimums(int[][] a1) {
		return null;
	} // getColumnMinimums
	
	/**
	 * In this problem, you are given two parameters:
	 *    m1 a Map<String, String>
	 *    eyeColor a String
	 *    
	 * The Key is a String containing a person's name
	 * The Value is a String containing a date of birth and eye color separated by a colon, i.e., ':'
	 * The format for the Value is mm-dd-yyyy:eye-color
	 * An example value is: 05-01-1993:blue  
	 * 
	 * You are to search Map m1 and return a count that indicates how many Values have 
	 * the eye color specified by the eyeColor parameter
	 * 
	 * Operation: countEyeColor
	 * 
	 * Incoming values:
	 * @param m1: Map<String, String>
	 * @param eyeColor: String
	 * 
	 * Outgoing value:
	 * @return int - a count of the number values in m1 that contain eyeColor
	 * 
	 * 
	 * Example 1
	 * Incoming values:
	 *    m1 = {Zoe=05-09-2007:hazel, Liam=05-01-1993:blue, Eli=07-14-2010:gray, Sarah=03-14-2001:blue}
	 *    eyeColor=blue
	 * Outgoing value:
	 *    2 is returned because Liam and Sarah have eye color blue
	 * 
	 * Example 2
	 * Incoming values:
	 *    m1 = {Zoe=05-09-2007:hazel, Liam=05-01-1993:blue, Eli=07-14-2010:gray, Sarah=03-14-2001:blue}
	 *    eyeColor=orange
	 * Outgoing value:
	 *    0 is returned because no one has eye color orange
	 * 
	 */	
	public static int countEyeColor(Map<String, String> m1, String eyeColor) {
		return -1;
	} // countEyeColor
	
	// -----------------------------------------------------------------------------
		
	/**
	 * In this problem, you are given three parameters:
	 *    m1 a Map<String, String>
	 *    currentEyeColor a String
	 *    newEyeColor a String
	 *    
	 * The Key is a String containing a person's name
	 * The Value is a String containing a date of birth and eye color separated by a colon, i.e., ':'
	 * The format for the Value is mm-dd-yyyy:eye-color
	 * An example value is: 05-01-1993:blue  
	 * 
	 * You are to modify Map m1 by changing all Values that have currentEyeColor to have newEyeColor
	 * 
	 * Operation: changeEyeColor
	 * 
	 * Incoming values:
	 * @param m1: Map<String, String>
	 * @param currentEyeColor: String
	 * @param newEyeColor: String
	 * 
	 * Outgoing Map m1 is same as incoming Map m1, except each value in the incoming Map m1
	 * that contains an eye color equal to currentEyeColor has that eye color changed to
	 * the newEyeColor in the outgoing Map m1	
	 * 
	 * Example 1
	 * Incoming values:
	 *    m1 = {Zoe=05-09-2007:hazel, Liam=05-01-1993:blue, Eli=07-14-2010:gray, Sarah=03-14-2001:blue}
	 *    currentEyeColor=blue
	 *    newEyeColor=orange
	 * Outgoing Map:
	 *    m1 = {Zoe=05-09-2007:hazel, Liam=05-01-1993:orange, Eli=07-14-2010:gray, Sarah=03-14-2001:orange}
	 *    
	 * 
	 * Example 2
	 * Incoming values:
	 *    m1 = {Zoe=05-09-2007:hazel, Liam=05-01-1993:blue, Eli=07-14-2010:gray, Sarah=03-14-2001:blue}
	 *    currentEyeColor=blue
	 *    newEyeColor=orange
	 * Outgoing Map:
	 *    m1 = {Zoe=05-09-2007:hazel, Liam=05-01-1993:orange, Eli=07-14-2010:gray, Sarah=03-14-2001:orange}
	 * 
	 */	
	public static void changeEyeColor(Map<String, String> m1, String currentEyeColor, String newEyeColor) {
		
	} // changeEyeColor	

}
