import java.util.ArrayList;

import org.hamcrest.MatcherAssert;

public class SmallProblems {

	
	/**
	 * In this problem, you are given two strings.  You are to return an 
	 * ArrayList of Characters such that all of the characters from the
	 * first input at EVEN indices are added and all the characters from
	 * the second input at ODD indices are added.  The characters should
	 * be interchanged between input1 and input2.
	 * 
	 * For simplicity, you can assume that the strings are the same length
	 * 
	 * For example:
	 * input1 = "Hello123"
	 * input2 = "Stringab"
	 * return an ArrayList of Characters = 
	 * {'H', 't', 'l', 'i', 'o', 'g', '2', 'b'}
	 * 
	 * Notice how the ArrayList is the two strings interchanged, with
	 * every other element.
	 * 
	 * As a second example:
	 * input1 = "1234567"
	 * input2 = "ABCDEFG"
	 * return an ArrayList of Characters =
	 * {'1', 'B', '3', 'D', '5', 'F', '7'}
	 * 
	 * @param input1 the first input String (to be interchanged with the other)
	 * @param input2 the second input String (to be interchanged with the other)
	 * @return an ArrayList of Characters containing every other element of
	 * the two Strings interchanged as shown above
	 */
	public static ArrayList<Character> interchange(String input1, String input2) {
		return null;
	}
	
	/**
	 * For this problem, you are given an integer array.  You are to count all the
	 * integers that are different powers of 2.  For simplicity, the largest power of 
	 * 2 that will be used is 20 (1,048,576).
	 * 
	 * For example:
	 * Given the input array = {1, 2, 3, 4, 5, 6, 7, 8}
	 * You should return a count of 4 because there are 4 different integers
	 * in the array that are a power of 2 (1(=2^0), 2(=2^1), 4(=2^2) and 8(=2^3))
	 * 
	 * As another example:
	 * Given the input array = {3, 5, 6, 7, 9, 10, 11}
	 * You should return a count of 0 because none of the numbers in the array
	 * is a power of 2.
	 * 
	 * Another example:
	 * Given the input array = {1, 2, 4, 8, 16, 32}
	 * You should return a count of 6 because all 6 integers are a power of 2
	 *  
	 * @param input - the input integer array of numbers
	 * @return the count of integers in the input array that are powers of 2
	 */
	public static int countPowersOf2(int[] input) {
		return 0;
	}
	
	/**
	 * For this problem, you are given two arrays.  one array is an integer array
	 * of values.  The other is a character array to indicate operations.
	 * The possible characters that appear in the character array are
	 * '/' - indicates division
	 * '*' - indicates multiplication
	 * '+' - indicates addition
	 * '-' - indicates subtraction
	 * 
	 * You are to return an ArrayList of integers containing the result of applying
	 * the operation on the subsequent pairs of numbers in the integer array.  The array
	 * of operations is thus half the size of the integer array.
	 * 
	 * As a small example:
	 * numbers = {1, 2}
	 * operations = {'+'}
	 * 
	 * The operation indicates that the values 1 and 2 should be added.  Therefore,
	 * this should result in returning an ArrayList with a single integer = {3}
	 * 
	 * Another example:
	 * numbers = {1, 1, 2, 2, 3, 3, 4, 4, 5, 5}
	 * operations = {'+', '*', '/', '-', '+'}
	 * Given these inputs, it indicates that you should do the following operations:
	 * 1 + 1 = 2
	 * 2 * 2 = 4
	 * 3 / 3 = 1
	 * 4 - 4 = 0
	 * 5 + 5 = 10
	 * 
	 * Thus, the ArrayList = {2, 4, 1, 0, 10} should be returned.
	 * 
	 * As a final example:
	 * numbers = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10}
	 * operations = {'/', '+', '-', '*', '+'}
	 * Given these inputs, it indicates that you should do the following operations:
	 * 1 / 2 = 0  (integer divided by an integer is an integer result, 0.5 to an int is 0)
	 * 3 + 4 = 7
	 * 5 - 6 = -1
	 * 7 * 8 = 56
	 * 9 + 10 = 19
	 * 
	 * Thus, the ArrayList = {0, 7, -1, 56, 19} should be returned.
	 * 
	 *  
	 * @param numbers - the array of integers that the operations should be applied to
	 * @param operations - a character array indicating the operation to perform on the
	 * next subsequent pair of numbers
	 * @return an ArrayList of Integers that contain the results of the operations applied
	 * to the respective pair of integers
	 */
	public static ArrayList<Integer> applyOperations(int[] numbers, char[] operations) {
		return null;
	}
}

