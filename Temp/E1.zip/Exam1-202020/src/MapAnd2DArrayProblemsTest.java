import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

public class MapAnd2DArrayProblemsTest {
	

	// -----------------------------------------------------------------------------
	// Helper Operations
	// -----------------------------------------------------------------------------
	
	HashMap<String,String> toMap(String[] keys, String[] values) {
		HashMap<String,String> result = new HashMap<String,String>();
		for(int i = 0; i < keys.length; i++) {
			result.put(keys[i], values[i]);
		} // end for
		return result;
	} // toMap
	

	// -----------------------------------------------------------------------------
	// Begin Test Cases
	// -----------------------------------------------------------------------------
	
	
	
	// -----------------------------------------------------------------------------
	// sumOfAllOddNumbers - 2 test cases
	// -----------------------------------------------------------------------------
	
	@Test
	public void testSumOfAllOddNumbersResultZero() {
		int[][] test0 = {};
		assertEquals(0, MapAnd2DArrayProblems.sumOfAllOddNumbers(test0));
		
		int[][] test1 = {{46, 22}, {0, 100}};
		assertEquals(0, MapAnd2DArrayProblems.sumOfAllOddNumbers(test1));
	} // testSumOfAllOddNumbersResultZero
	
	
	@Test
	public void testSumOfAllOddNumbersResultNonZero() {
		int[][] test0 = {{47, 55}, {23, 7}};
		assertEquals(132, MapAnd2DArrayProblems.sumOfAllOddNumbers(test0));
		

		int[][] test1 = {{50, 111}, {5, 0}, {87,31}, {3, 77}, {100, 0}, {101, 12}};
		assertEquals(415, MapAnd2DArrayProblems.sumOfAllOddNumbers(test1));
	} // testSumOfAllOddNumbersResultNonZero
	

	// -----------------------------------------------------------------------------
	// getColumnMinimums - 1 test case
	// -----------------------------------------------------------------------------
	
	@Test
	public void testGetColumnMinimums() {		
		int[][] test0 = {{47, -55}, {23, 7}};
		ArrayList<Integer> expected0 = 
				new ArrayList<Integer>(Arrays.asList(new Integer[] {23, -55}));
		assertEquals(expected0, MapAnd2DArrayProblems.getColumnMinimums(test0));
		
		
		int[][] test1 = {{10, 17, -5}, {32, 5, 7}, {3, 7, 1}};
		ArrayList<Integer> expected1 = 
				new ArrayList<Integer>(Arrays.asList(new Integer[] {3, 5, -5}));
		assertEquals(expected1, MapAnd2DArrayProblems.getColumnMinimums(test1));
		
		int[][] test2 = {{50, 111}, {5, 0}, {87,31}, {3, 77}, {100, 0}, {-100, 12}};
		ArrayList<Integer> expected2 = 
				new ArrayList<Integer>(Arrays.asList(new Integer[] {-100, 0}));
		assertEquals(expected2, MapAnd2DArrayProblems.getColumnMinimums(test2));	
	} // testGetColumnMinimums
	
	// -----------------------------------------------------------------------------
	// countEyeColor - 2 test cases
	// -----------------------------------------------------------------------------
	
	@Test
	public void testCountEyeColorResultIsZero() {
		final String[] names0 = {};
		final String[] dobEyeColor0 = {};
		
		final String[] names1 = {
				"Sarah", "Sophia", "Liam",
				"Jackson", "Mia", "Michael",
				"Eli", "Eleanor", "Zoe"};
		final String[] dobEyeColor1 = {
				"03-14-2001:blue", "10-25-1999:hazel", "05-01-1993:blue",
				"04-24-2011:brown", "12-25-2003:green", "08-09-1995:blue",
				"07-14-2010:gray", "06-10-2000:gray", "05-09-2007:hazel"};
		
		Map<String, String> m0 = toMap(names0, dobEyeColor0);
		Map<String, String> m1 = toMap(names1, dobEyeColor1);
		
		assertEquals(0, MapAnd2DArrayProblems.countEyeColor(m0, "gray"));
		assertEquals(0, MapAnd2DArrayProblems.countEyeColor(m1, "orange"));		
	} // testCountEyeColorEmptyMap
	
	
	@Test
	public void testCountEyeColorResultNonZero() {
		final String[] names = {
				"Sarah", "Sophia", "Liam",
				"Jackson", "Mia", "Michael",
				"Eli", "Eleanor", "Zoe"};
		final String[] dobEyeColor = {
				"03-14-2001:blue", "10-25-1999:hazel", "05-01-1993:blue",
				"04-24-2011:brown", "12-25-2003:green", "08-09-1995:blue",
				"07-14-2010:gray", "06-10-2000:gray", "05-09-2007:hazel"};
		Map<String, String> m1 = toMap(names, dobEyeColor);
		
		assertEquals(3, MapAnd2DArrayProblems.countEyeColor(m1, "blue"));
		assertEquals(2, MapAnd2DArrayProblems.countEyeColor(m1, "gray"));	
	} // testCountEyeColorResultNonZero
	
	// -----------------------------------------------------------------------------
	// changeEyeColor - 1 test case
	// -----------------------------------------------------------------------------
		
	@Test
	public void testChangeEyeColor() {
		final String[] names = {
				"Sarah", "Sophia", "Liam",
				"Jackson", "Mia", "Michael",
				"Eli", "Eleanor", "Zoe"};
		final String[] dobEyeColor = {
				"03-14-2001:blue", "10-25-1999:hazel", "05-01-1993:blue",
				"04-24-2011:brown", "12-25-2003:green", "08-09-1995:blue",
				"07-14-2010:gray", "06-10-2000:gray", "05-09-2007:hazel"};
		Map<String, String> m1 = toMap(names, dobEyeColor);
		
		MapAnd2DArrayProblems.changeEyeColor(m1, "blue", "orange");
		
		assertEquals("03-14-2001:orange", m1.get("Sarah"));	
		assertEquals("05-01-1993:orange", m1.get("Liam"));	
		assertEquals("08-09-1995:orange", m1.get("Michael"));
		

		assertEquals("05-09-2007:hazel", m1.get("Zoe"));	
	} // testChangeEyeColor

}
