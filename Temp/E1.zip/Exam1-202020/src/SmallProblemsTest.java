import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

import org.junit.Test;

public class SmallProblemsTest {
	
	@Test
	public void testInterchange() {
		String input1 = "1234567";
		String input2 = "ABCDEFG";
		Character[] resultArray = {'1', 'B', '3', 'D', '5', 'F', '7'};
		ArrayList<Character> result = new ArrayList<Character>(Arrays.asList(resultArray));
		
		assertTrue(result.equals(SmallProblems.interchange(input1, input2)));
		
		input1 = "Hello123";
		input2 = "Stringab";
		resultArray = new Character[]{'H', 't', 'l', 'i', 'o', 'g', '2', 'b'};
		result = new ArrayList<Character>(Arrays.asList(resultArray));
		
		assertTrue(result.equals(SmallProblems.interchange(input1, input2)));
		
		input1 = "";
		input2 = "";
		resultArray = new Character[]{};
		result = new ArrayList<Character>(Arrays.asList(resultArray));
		
		assertTrue(result.equals(SmallProblems.interchange(input1, input2)));
		
		input1 = "ABC";
		input2 = "DEF";
		resultArray = new Character[]{'A', 'E', 'C'};
		result = new ArrayList<Character>(Arrays.asList(resultArray));
		
		assertTrue(result.equals(SmallProblems.interchange(input1, input2)));
		
		
		input1 = "AB";
		input2 = "DE";
		resultArray = new Character[]{'A', 'E'};
		result = new ArrayList<Character>(Arrays.asList(resultArray));
		
		assertTrue(result.equals(SmallProblems.interchange(input1, input2)));
		
		//big test
		input1 = "";
		input2 = "";
		result = new ArrayList<Character>();
		int firstAsciiLetter = 97; //ASCII value of letter 'a'
		int lastAsciiLetter = 122; //ASCII value of letter 'z'
		for (int i = 0; i < 200; i++) { //make a 200 character string that contains all lower-case letters
			char tempChar1 = (char) ((i%(lastAsciiLetter-firstAsciiLetter+1))+firstAsciiLetter);
			char tempChar2 = (char) (((i+1)%(lastAsciiLetter-firstAsciiLetter+1))+firstAsciiLetter);
			input1 += "" + tempChar1;
			input2 += "" + tempChar2;
			if(i%2==0)
				result.add(tempChar1);
			else
				result.add(tempChar2);
		}
		
		assertTrue(result.equals(SmallProblems.interchange(input1, input2)));
	}
	
	@Test
	public void testCountPowersOf2() {
		int[] test = {1, 2, 3, 4, 5, 6, 7, 8};
		assertEquals(4, SmallProblems.countPowersOf2(test));
		
		test = new int[] {1, 1, 1, 1, 1, 1, 1, 1};
		assertEquals(test.length, SmallProblems.countPowersOf2(test));
		
		test = new int[] {3, 3, 3, 3, 3, 3, 3, 3, 3};
		assertEquals(0, SmallProblems.countPowersOf2(test));
		
		test = new int[21];
		for(int i = 0; i <= 20; i++) {
			test[i] = (int)Math.pow(2, i);
		}
		assertEquals(test.length, SmallProblems.countPowersOf2(test));
		
		
		
		//big test 
		test = new int[1048577];
		for(int i = 0; i < test.length; i++) {
			test[i] = i;
		}
		
		assertEquals(21, SmallProblems.countPowersOf2(test));
	}
	
	@Test
	public void testApplyOperations() {
		int[] test = {1, 1, 2, 2, 3, 3, 4, 4, 5, 5};
		char[] ops = {'+', '*', '/', '-', '+'};
		Integer[] temp = {2, 4, 1, 0, 10};
		ArrayList<Integer> result = new ArrayList<Integer>(Arrays.asList(temp));
		ArrayList<Integer> returned = SmallProblems.applyOperations(test, ops);
		
		assertTrue(result.equals(returned));
		
		test = new int[] {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
		ops = new char[] {'/', '+', '-', '*', '+'};
		temp = new Integer[] {0, 7, -1, 56, 19};
		
		result = new ArrayList<Integer>(Arrays.asList(temp));
		returned = SmallProblems.applyOperations(test, ops);
		
		assertTrue(result.equals(returned));
		
		test = new int[] {1, 2};
		ops = new char[] {'+'};
		temp = new Integer[] {3};
		result = new ArrayList<Integer>(Arrays.asList(temp));
		assertTrue(result.equals(SmallProblems.applyOperations(test, ops)));
		
		test = new int[] {1, 2};
		ops = new char[] {'-'};
		temp = new Integer[] {-1};
		result = new ArrayList<Integer>(Arrays.asList(temp));
		assertTrue(result.equals(SmallProblems.applyOperations(test, ops)));
		
		test = new int[] {4, 2};
		ops = new char[] {'/'};
		temp = new Integer[] {2};
		result = new ArrayList<Integer>(Arrays.asList(temp));
		assertTrue(result.equals(SmallProblems.applyOperations(test, ops)));
		
		test = new int[] {2, 5};
		ops = new char[] {'*'};
		temp = new Integer[] {10};
		result = new ArrayList<Integer>(Arrays.asList(temp));
		assertTrue(result.equals(SmallProblems.applyOperations(test, ops)));
		
		
		
		//big test, iterate over ascii table lower-case characters
		test = new int[500];
		ops = new char[250];
		result = new ArrayList<Integer>();
		char[] possOps = {'+', '-', '/', '*'};
		int testIndex = 0;
		for (int i = 0; i < 250; i++) { 
			char curOp = possOps[i%possOps.length];
			ops[i] = curOp;
			test[testIndex] = i;
			test[testIndex+1] = i*2;
			
			if(curOp == '+') {
				result.add(test[testIndex] + test[testIndex+1]);
			} else if(curOp == '-') {
				result.add(test[testIndex] - test[testIndex+1]);
			} else if(curOp == '*') {
				result.add(test[testIndex] * test[testIndex+1]);
			} else if(curOp == '/') {
				result.add(test[testIndex] / test[testIndex+1]);
			}
			
			testIndex += 2;
		}
		
		returned = SmallProblems.applyOperations(test, ops);
		assertTrue(result.equals(returned));
	}
}

