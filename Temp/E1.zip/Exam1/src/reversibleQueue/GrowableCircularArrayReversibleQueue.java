package reversibleQueue;

import java.lang.reflect.Array;
import java.util.NoSuchElementException;

/**
 * A class to implement the ReversibleQueue ADT, using a growable circular array.
 *
 * @author Nate Chenette
 *         Created Sep 18, 2018.
 */

public class GrowableCircularArrayReversibleQueue<T> implements ReversibleQueue<T> {
	
	private static final int INITIAL_CAPACITY = 5;

	private T[] array;     // primitive array to hold the queue contents
	private int head;      // the index of the head of the queue
	private int size;      // number of items in the queue
	private Class<T> type; // type of queue items. Needed for reallocation steps

	
	/**
	 * Creates an empty queue with an initial capacity of 5
	 * 
	 * @param type
	 *            So that an array of this type can be constructed.
	 */
	@SuppressWarnings("unchecked")
	public GrowableCircularArrayReversibleQueue(Class<T> type) {
		this.type = type;
		this.array = (T[]) Array.newInstance(type, INITIAL_CAPACITY);
		this.head = 0;
		this.size = 0;
	}
	

	@SuppressWarnings("unchecked")
	private void resize() {
		int oldSize = this.array.length;
		int newSize = oldSize * 2;
		T[] original = this.array;

		this.array = (T[]) Array.newInstance(type, newSize);
		for (int i = 0; i < this.size; i++) {
			this.array[i] = original[(this.head + i) % original.length];
		}
		this.head = 0;
	}


	@Override
	public void enqueue(T item) {
		if (this.size >= this.array.length) {
			resize();
		}
		this.array[(this.head + this.size) % this.array.length] = item;
		this.size++;
	}

	@Override
	public T dequeue() {
		if (isEmpty()) {
			throw new NoSuchElementException(
					"Cannot remove from an empty queue");
		}
		T item = this.array[this.head];
		this.head = (this.head + 1) % this.array.length;
		this.size--;
		return item;
	}


	@Override
	public boolean isEmpty() {
		return this.size == 0;
	}


	@Override
	public void reverse() {
		// TODO Implement me!
		// You may also want to change the enqueue and dequeue methods. 
		
	}
	

}
