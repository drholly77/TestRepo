package reversibleQueue;

import java.util.LinkedList;
import java.util.NoSuchElementException;

/**
 * A class to implement the ReversibleQueue ADT, using a doubly-linked list.
 *
 * @author Nate Chenette
 *         Created Sep 18, 2018.
 */

public class DoublyLinkedListReversibleQueue<T> implements ReversibleQueue<T> {
	
	private LinkedList<T> list;
	
	public DoublyLinkedListReversibleQueue() {
		list = new LinkedList<T>();
	}

	public void enqueue(T item) {
		list.add(item);
	}

	public T dequeue() {
		if (isEmpty()) {
			throw new NoSuchElementException(
					"Cannot remove from an empty queue");
		}
		return list.remove();	
	}

	public boolean isEmpty() {
		return list.isEmpty();
	}

	@Override
	public void reverse() {
		// TODO Implement me!
		// You may also want to change the enqueue and dequeue methods. 
		
	}

	
	
	
}
