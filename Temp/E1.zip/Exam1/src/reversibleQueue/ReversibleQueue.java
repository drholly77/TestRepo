package reversibleQueue;

/**
 * An interface for the ReversibleQueue ADT.
 *
 * @author Nate Chenette
 *         Created Sept 18, 2018.
 */

public interface ReversibleQueue<T> {
	
	public void enqueue(T item);
	public T dequeue();
	public boolean isEmpty();
	public void reverse();
	
}
