package reversibleQueue;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.Test;

public class DoublyLinkedListReversibleQueueTest {
	
	private static int totalPoints = 0;
	private static boolean baselinePassed = false;
	
	
	// Test to make sure we haven't messed up enqueue, dequeue, or isEmpty.
	@Test
	public void testBaseline() {
		ReversibleQueue<String> q = new DoublyLinkedListReversibleQueue<>();
		assertTrue(q.isEmpty());
		q.enqueue("one");
		assertFalse(q.isEmpty());
		q.enqueue("two");
		q.enqueue("three");
		assertEquals("one",q.dequeue());
		assertFalse(q.isEmpty());
		q.enqueue("four");
		assertEquals("two",q.dequeue());
		assertEquals("three",q.dequeue());
		assertEquals("four",q.dequeue());
		assertTrue(q.isEmpty());
		q.enqueue("five");
		assertEquals("five",q.dequeue());
		baselinePassed = true;
	}
	
	@Test
	public void testReverseBasic() {
		ReversibleQueue<String> q = new DoublyLinkedListReversibleQueue<>();
		q.enqueue("one");
		q.enqueue("two");
		q.enqueue("three");
		assertEquals("one",q.dequeue());
		q.reverse();
		assertEquals("three",q.dequeue());
		assertFalse(q.isEmpty());
		assertEquals("two",q.dequeue());
		assertTrue(q.isEmpty());
		totalPoints += 4;
	}
	
	@Test
	public void testReverseThenEnqueue() {
		ReversibleQueue<String> q = new DoublyLinkedListReversibleQueue<>();
		q.enqueue("one");
		q.enqueue("two");
		q.enqueue("three");
		q.enqueue("four");                   // Now [1,2,3,4]
		assertEquals("one",q.dequeue());
		assertEquals("two",q.dequeue());     // Now [3,4]
		q.reverse();							// Now [4,3]
		q.enqueue("five");
		q.enqueue("six");					// Now [4,3,5,6]
		assertEquals("four",q.dequeue());
		assertEquals("three",q.dequeue());
		assertEquals("five",q.dequeue());
		assertEquals("six",q.dequeue());
		assertTrue(q.isEmpty());
		totalPoints += 4;
	}
	
	@Test
	public void testMultipleReverses() {
		ReversibleQueue<String> q = new DoublyLinkedListReversibleQueue<>();
		q.enqueue("one");
		q.enqueue("two");
		q.enqueue("three");                  // Now [1,2,3]
		assertEquals("one",q.dequeue());		// Now [2,3]
		q.reverse();							// Now [3,2]
		q.enqueue("five");
		q.enqueue("six");					// Now [3,2,5,6]
		q.reverse();							// Now [6,5,2,3]
		q.enqueue("seven");					// Now [6,5,2,3,7]
		assertEquals("six",q.dequeue());
		assertEquals("five",q.dequeue());
		assertEquals("two",q.dequeue());
		assertEquals("three",q.dequeue());
		assertEquals("seven",q.dequeue());
		assertTrue(q.isEmpty());
		totalPoints += 4;
	}
	

	

	// Tests to see if reverse is running efficiently.
	@Test
	public void testSpeedOfReverse() {
		ReversibleQueue<Integer> q = new DoublyLinkedListReversibleQueue<>();
		Integer maxVal = 1000000;
		Integer maxValminus1 = maxVal - 1;
		for (Integer i = 0; i <= maxVal; i++) {
			q.enqueue(i);
		}
		double beforeTime = System.currentTimeMillis();
		q.reverse();
		double afterTime = System.currentTimeMillis();

		assertEquals(maxVal,q.dequeue());
		assertEquals(maxValminus1,q.dequeue());
		
		double timeDiff = afterTime - beforeTime;
		System.out.println("DoublyLinkedListReversibleQueue time for reverse (want <5 ms):      " + String.valueOf((int) timeDiff) + " ms");
		assertTrue(timeDiff < 5);
	
		totalPoints += 6;
	}
	
	


	@AfterClass
	public static void showPoints() {
		if (!baselinePassed) {
			totalPoints /= 2;
			System.out.printf("50% point penalty for losing original functionality");
		}
		
		System.out.printf("DoublyLinkedListReversibleQueue points:      %d/18\n",totalPoints);
	}
}
