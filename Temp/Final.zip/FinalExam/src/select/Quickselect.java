package select;

import java.util.Random;

public class Quickselect {

	/**
	 * Selects the k-th largest element of the given array,
	 * using the quickselect algorithm.
	 * The given array should be left unchanged. (We provide an initial
	 * clone command that copies the givenArray over to a new array,
	 * so you can do whatever you want to the clone.)
	 * 
	 * Pivot selection: when partitioning a part of the array between
	 * index _low_ and index _high_, you should *always use* 
	 * 		array[_low_]
	 * as the pivot.
	 * 
	 * Solutions that completely sort the array will be given no credit!
	 * 
	 * @param givenArray
	 * @param k
	 */
	public static int select(int[] givenArray, int k) {
		int[] array = givenArray.clone();
		// TODO: implement quickselect on the cloned array, so the
		// given array isn't modified.
		
		return -1;
	}
	
	/**
	 * This method intends to fill the given int array with data,
	 * arranging the data and returning an index in such a way that
	 * 		select(array, index)
	 * will run as long as possible.
	 * 
	 * @param example
	 * @return
	 */
	public static int worstCaseFillArray(int[] example) {
		// TODO: replace the following line with some code that will
		// populate the array, example, and return an index such that
		// select(example, index) will run as long as possible given
		// the array length of the provided array.
		return randomFillArray(example);
	}
	
	/**
	 * Fills the given int array with random data in the range [0,array.length],
	 * returns the median index array.length/2.
	 * 
	 * @param example
	 * @return
	 */
	public static int randomFillArray(int[] example) {
		Random rand = new Random();
		int len = example.length;
		for (int i = 0; i < len; i++) {
			example[i] = rand.nextInt(len);
		}
		return len/2;
	}

}
