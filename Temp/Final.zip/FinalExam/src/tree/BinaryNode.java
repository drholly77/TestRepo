package tree;

public abstract class BinaryNode {
	public abstract BinaryNode insert(Integer e);
	public abstract String toString();
}
