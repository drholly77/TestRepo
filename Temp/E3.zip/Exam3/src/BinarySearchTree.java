
import java.util.NoSuchElementException;

/**
 * @author TODO: your name here.
 */
public class BinarySearchTree {
	private BinaryNode root;

	private final BinaryNode NULL_NODE = new BinaryNode();

	public BinarySearchTree() {
		root = NULL_NODE;
	}

	/**
	 * Returns true iff the BST is balanced within toleranceLevel That is, it
	 * returns true if at each node in the tree 
	 * |height(leftSubtree) - height(rightSubtree)| <= toleranceLevel
	 * 
	 * For example, if t1.isBalancedWithinTolerance(1) returns true, then t1 is an
	 * AVL tree
	 */
	public boolean isBalancedWithinTolerance(int toleranceLevel) {
//		 TODO: Write me!
		return false;
	}
	
	/**
	 * Returns a new BinarySearchTree that is a copy of the original except that
	 * the only nodes in the new tree are nodes that correspond to nodes in the
	 * original tree that make up the path from the root to the deepest leaf and
	 * no other nodes appear in the new tree
	 * @return
	 */
	public BinarySearchTree buildSkinnyTreeFromRootToDeepestLeaf() {
//		 TODO: Write me! 
		return this;		
	}

	public boolean isEmpty() {
		return root == NULL_NODE;
	}

	public void insert(Integer item) {
		root = root.insert(item);
	}

	@Override
	public String toString() {
		StringBuilder retVal = new StringBuilder();
		root.toStringHelper(retVal);
		return retVal.toString();
	}
	

	// ************************************************************************************
	// BinaryNode class begins here
	// ************************************************************************************
	

	private class BinaryNode {
		// ****************************************************
		// You may not add or remove fields to BinaryNode class
		// You may add methods to BinaryNode class
		// ****************************************************
		private Integer data;
		private BinaryNode left;
		private BinaryNode right;

		public BinaryNode() {
			this.data = null;
			this.left = null;
			this.right = null;
		}

		public BinaryNode(Integer element) {
			this.data = element;
			this.left = NULL_NODE;
			this.right = NULL_NODE;
		} // BinaryNode

		public BinaryNode insert(Integer item) {
			if (this == NULL_NODE) {
				return new BinaryNode(item);
			} // end if
			int comp = item.compareTo(data);
			if (comp < 0) {
				left = left.insert(item);
			} else if (comp > 0) {
				right = right.insert(item);
			} // end if
			return this;
		} // insert
		
		public void toStringHelper(StringBuilder sb) {
			if (this != NULL_NODE) {
				StringBuilder leftSb = new StringBuilder();
				StringBuilder rightSb = new StringBuilder();

				this.left.toStringHelper(leftSb);
				this.right.toStringHelper(rightSb);
				sb.append(leftSb);
				sb.append(this.data);
				sb.append(rightSb);
			} // end if
		} // toStringHelper
	}
}
