import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.Test;


public class BSTTesting {

	private static int indexOfPoints = 0;

	@Test
	public void testV01SkinnyTree() {
		BinarySearchTree t = new BinarySearchTree();

		// 10
		//   20
		//     30
		//       40
		//         50
		//           60
		t.insert(10);
		t.insert(20);
		t.insert(40);
		t.insert(50);
		t.insert(60);
		assertFalse(t.isBalancedWithinTolerance(0));
		assertFalse(t.isBalancedWithinTolerance(1));
		assertFalse(t.isBalancedWithinTolerance(2));
		assertFalse(t.isBalancedWithinTolerance(3));
		assertTrue(t.isBalancedWithinTolerance(4));
		indexOfPoints += 7;
	}	
	
	@Test
	public void testV02ZigZagSkinnyTree() {
		BinarySearchTree t = new BinarySearchTree();

		// 10
		//   20
		// 15
		//   18
		// 16
		//   17
		t.insert(10);
		t.insert(20);
		t.insert(40);
		t.insert(50);
		t.insert(60);
		assertFalse(t.isBalancedWithinTolerance(0));
		assertFalse(t.isBalancedWithinTolerance(1));
		assertFalse(t.isBalancedWithinTolerance(2));
		assertFalse(t.isBalancedWithinTolerance(3));
		assertTrue(t.isBalancedWithinTolerance(4));
		indexOfPoints += 7;
	}	
	
	@Test
	public void testV03BalancedTree() {
		BinarySearchTree t = new BinarySearchTree();

		//         40
		//    20       60
		//  10  30   50  70

		t.insert(40);
		
		t.insert(20);
		t.insert(10);
		t.insert(30);
		
		t.insert(60);
		t.insert(50);
		t.insert(70);
		assertTrue(t.isBalancedWithinTolerance(0));
		assertTrue(t.isBalancedWithinTolerance(1));
		assertTrue(t.isBalancedWithinTolerance(2));
		assertTrue(t.isBalancedWithinTolerance(3));
		assertTrue(t.isBalancedWithinTolerance(4));
		indexOfPoints += 7;
	}	
	
	@Test
	public void testV04EmptyTree() {
		BinarySearchTree t = new BinarySearchTree();

		assertTrue(t.isBalancedWithinTolerance(0));
		assertTrue(t.isBalancedWithinTolerance(1));
		assertTrue(t.isBalancedWithinTolerance(2));
		assertTrue(t.isBalancedWithinTolerance(3));
		assertTrue(t.isBalancedWithinTolerance(4));
		indexOfPoints += 7;
	}	


	@Test
	public void testV05BuildSkinnyTree() {
		BinarySearchTree t = new BinarySearchTree();

		//        40
		//   20           60
		//  10        50      70
		//         47    55      75
		//           49

		t.insert(40);
		
		t.insert(20);
		t.insert(10);
		
		t.insert(60);
		t.insert(70);
		t.insert(50);
		t.insert(47);
		t.insert(49);
		t.insert(75);
		BinarySearchTree skinnyTree = t.buildSkinnyTreeFromRootToDeepestLeaf();
		assertTrue(skinnyTree.toString().equals("4047495060"));
		indexOfPoints += 7;
	}	
	
	@Test
	public void testV06BuildSkinnyTree() {
		BinarySearchTree t = new BinarySearchTree();

		// 10
		//   20
		// 15
		//   18
		// 16
		//   17
		t.insert(10);
		t.insert(20);
		t.insert(40);
		t.insert(50);
		t.insert(60);
		BinarySearchTree skinnyTree = t.buildSkinnyTreeFromRootToDeepestLeaf();
		assertTrue(skinnyTree.toString().equals("1020405060"));
		indexOfPoints += 7;
	}	
	
	@Test
	public void testV07BuildSkinnyTree() {
		BinarySearchTree t = new BinarySearchTree();

		//        40
		//    20       60
		//  10           70
		// 5               75

		t.insert(40);
		
		t.insert(20);
		t.insert(10);
		t.insert(5);
		
		t.insert(60);
		t.insert(70);
		t.insert(75);
		BinarySearchTree skinnyTree = t.buildSkinnyTreeFromRootToDeepestLeaf();
		assertTrue(skinnyTree.toString().equals("40607075"));
		indexOfPoints += 7;
	}
	
	
	@Test
	public void testV08BuildSkinnyTree() {
		BinarySearchTree t = new BinarySearchTree();

		BinarySearchTree skinnyTree = t.buildSkinnyTreeFromRootToDeepestLeaf();
		assertTrue(skinnyTree.toString().equals(""));
		indexOfPoints += 6;
	}
	
	@AfterClass
	public static void displayPoints() {
		System.out.printf("indexOf points:                  %2d/55\n", indexOfPoints);
	}
}